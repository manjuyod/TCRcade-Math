# Copyright 2022 ByteDance and/or its affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import io
from absl import logging
import os
import uuid
import random
import struct
import tensorflow as tf
import tempfile
import threading
from typing import List, BinaryIO
from idl.matrix.proto import proto_parser_pb2, example_pb2, feature_pb2
from monolith.native_training.data.datasets import PBDataset, PbType
from monolith.native_training.data.parsers import parse_instances, \
  parse_examples
from monolith.native_training.model_export.data_gen_utils import lg_header, sort_header
from monolith.native_training.data.feature_utils import (
    add_action, add_label, feature_combine, filter_by_fids, filter_by_label, filter_by_feature_value,
    filter_by_value, scatter_label, switch_slot, switch_slot_batch, map_id, use_field_as_label,
    label_upper_bound, label_normalization, multi_label_gen, string_to_variant,
    variant_to_zeros, has_variant, negative_sample, gen_fid_mask)

fid_v1_mask = (1 << 54) - 1
fid_v2_mask = (1 << 48) - 1


def get_fid_v1(slot: int, signautre: int):
  return (slot << 54) | (signautre & fid_v1_mask)


def get_fid_v2(slot: int, signature: int):
  return (slot << 48) | (signature & fid_v2_mask)


features = {
    'f_spm_1': 301,
    'f_spm_3': 303,
    'f_spm_2': 302,
    'f_spm_4': 304,
    'f_user_id': 1,
    'f_user_ctx_network': 61,
    'f_user_id-f_page': 504,
    'f_scm': 306,
    'f_goods_id': 200,
    'f_goods_sale_number_1000': 225,
    'f_goods_praise_cnt': 229,
    'f_spm': 300,
    'f_page': 305,
    'f_is_dup': 310,
    'f_user_ctx_platform': 52,
    'f_goods_title_terms': 209,
    'f_goods_tags_terms': 211,
    'f_user_test09_array_int32': 554,
    'f_user_test15_array_float': 540,
    'f_user_test14_array_bool': 543,
    'f_user_test12_array_uint64': 551,
    'f_user_test10_array_int64': 549
}

group_slots = [
    200, 201, 202, 203, 204, 205, 206, 210, 211, 212, 213, 214, 215, 216, 217,
    218, 219, 220, 221, 222, 223, 224, 225, 230, 231, 232, 233, 234, 235, 236,
    237, 238, 239, 240, 241, 242
]


def parse_instance_or_example(tensor: tf.Tensor, out_type,
                              extra_sparse_features: List[str] = None):
  fidv1_features = [
      1, 2, 32, 33, 36, 38, 42, 50, 54, 56, 60, 66, 120, 150, 180, 182, 192,
      220, 333, 410, 412, 422, 446
  ]
  if out_type == PbType.INSTANCE:
    return parse_instances(tensor,
                           fidv1_features,
                           dense_features=['label'],
                           dense_feature_shapes=[2],
                           dense_feature_types=[tf.float32],
                           extra_features=[
                               'uid', 'req_time', 'item_id', 'actions',
                               'video_finish_percent'
                           ],
                           extra_feature_shapes=[1, 1, 1, 2, 1])
  else:
    return parse_examples(
        tensor,
        sparse_features=[f'fc_slot_{slot}' for slot in fidv1_features] + \
          extra_sparse_features if extra_sparse_features else [],
        dense_features=['label'],
        dense_feature_shapes=[2],
        dense_feature_types=[tf.float32],
        extra_features=[
            'uid', 'req_time', 'item_id', 'actions', 'video_finish_percent'
        ],
        extra_feature_shapes=[1, 1, 1, 3, 1])


def parse_example_batch(tensor: tf.Tensor, out_type,
                        extra_sparse_features: List[str] = None):
  if out_type == PbType.INSTANCE:
    feature_dict = parse_instances(tensor,
                                   fidv1_features=list(features.values()),
                                   dense_features=['label'],
                                   dense_feature_shapes=[2],
                                   dense_feature_types=[tf.float32],
                                   extra_features=[
                                       'uid', 'req_time', 'item_id', 'actions',
                                       'video_finish_percent'
                                   ],
                                   extra_feature_shapes=[1, 1, 1, 3, 1])
  else:
    feature_dict = parse_examples(tensor,
                                  sparse_features=list(features.keys()) + \
                                    extra_sparse_features if extra_sparse_features else [],
                                  dense_features=['label'],
                                  dense_feature_shapes=[2],
                                  dense_feature_types=[tf.float32],
                                  extra_features=[
                                      'uid', 'req_time', 'item_id', 'actions',
                                      'video_finish_percent'
                                  ],
                                  extra_feature_shapes=[1, 1, 1, 3, 1])
    # print(feature_dict)
    # feature_dict['f_page'] = switch_slot(feature_dict['f_page'], slot=306)
    # feature_dict['f_user_id-f_goods_tags_terms'] = feature_combine(
    #     feature_dict['f_user_id'], feature_dict['f_goods_tags_terms'], slot=505)
  return feature_dict

def line_id_to_feature(name, value):
  tmp_feature = feature_pb2.Feature()
  tmp_feature.name = name
  value_mapping = {
      str: lambda val: tmp_feature.bytes_value.append(val.encode()),
      int: tmp_feature.int64_value.append,
      float: tmp_feature.float_value.append,
  }
  if isinstance(value, list):
    if len(value) > 0:
      value_type = type(value[0])
  else:
    value_type = type(value)
  append_func = value_mapping.get(value_type)
  if append_func:
    if isinstance(value, list):
      for val in value:
          append_func(val)
    else:
      append_func(value)
  return tmp_feature

def generate_instance(labels: List[int],
                      actions: List[int],
                      chnid: int = None,
                      did: str = None,
                      fid_v1_list: List[int] = None,
                      device_type: str = None,
                      req_id: str = None,
                      chnids: List[int] = None,
                      video_play_time: float = None,
                      write_line_id_to_feature: bool = False,
                      shuffle_features: bool = False):
  instance = proto_parser_pb2.Instance()
  instance.fid.extend(fid_v1_list if fid_v1_list else [])
  instance.label.extend(labels)
  instance.line_id.user_id = "test_{}".format(uuid.uuid4())
  instance.line_id.uid = 100
  instance.line_id.sample_rate = 0.5
  instance.line_id.actions.extend(actions)
  features = []
  if chnid is not None:
    instance.line_id.chnid = chnid
    if write_line_id_to_feature:
      features.append(line_id_to_feature('chnid', chnid))
  if did is not None:
    instance.line_id.did = did
    if write_line_id_to_feature:
      features.append(line_id_to_feature('did', did))
  if device_type is not None:
    instance.line_id.device_type = device_type
  if req_id is not None:
    instance.line_id.req_id = req_id
    if write_line_id_to_feature:
      features.append(line_id_to_feature('req_id', req_id))
  if chnids is not None and write_line_id_to_feature:
    features.append(line_id_to_feature('chnids', chnids))
  if video_play_time is not None:
    instance.line_id.video_play_time = video_play_time
    if write_line_id_to_feature:
      features.append(line_id_to_feature('video_play_time', video_play_time))
  if shuffle_features:
    random.shuffle(features)
  instance.feature.extend(features)
  return instance


def write_instance_into_file(file: BinaryIO, instance):
  sort_id = str(instance.line_id.user_id)
  file.write(struct.pack('<Q', len(sort_id)))
  file.write(sort_id.encode())
  instance_serialized = instance.SerializeToString()
  file.write(struct.pack('<Q', len(instance_serialized)))
  file.write(instance_serialized)
  
# file_name = "monolith/native_training/data/training_instance/instance.pb"
# with tf.io.gfile.GFile(file_name, "rb") as f:
#   instance = parse_instance_from_file(f, True, False, True)
#   print(instance)
  
def parse_instance_from_file(stream, has_kafka_dump, has_kafka_dump_prefix, has_sort_id):
  size_t = 8
  # kafka_prefix part, skip 16 bytes.
  if has_kafka_dump_prefix:
    stream.read(size_t * 2)
  # sort id part, skip 8 bytes.
  if has_sort_id:
    size_binary = stream.read(size_t)[::-1]
    size = struct.unpack('>Q', size_binary)[0]
    sort_id = stream.read(size)
  else:
    sort_id = ""
  # proto.
  if has_kafka_dump:
    stream.read(size_t)

  # size + proto_binary
  # This is the proto part.
  size_binary = stream.read(size_t)[::-1]
  size = struct.unpack('>Q', size_binary)[0]
  proto_binary = stream.read(size)
  instance = proto_parser_pb2.Instance()
  instance.ParseFromString(proto_binary)
  return instance


class DataOpsTest(tf.test.TestCase):
  def pb_dataset_target(self,
                        input_pb_type,
                        output_pb_type,
                        filter_fn=None,
                        add_action_fn=None,
                        return_result_key='actions',
                        num_return_items=2):
    if input_pb_type == PbType.INSTANCE:
      lagrangex_header = False
      has_sort_id, kafka_dump, kafka_dump_prefix = True, True, False
      file_name = "monolith/native_training/data/training_instance/instance.pb"
    elif input_pb_type == PbType.EXAMPLE:
      lagrangex_header = False
      has_sort_id, kafka_dump, kafka_dump_prefix = True, True, False
      file_name = "monolith/native_training/data/training_instance/example.pb"
    else:
      lagrangex_header = True
      has_sort_id, kafka_dump, kafka_dump_prefix = False, False, False
      file_name = "monolith/native_training/data/training_instance/examplebatch.data"

    def parser(tensor: tf.Tensor):
      if output_pb_type == PbType.PLAINTEXT:
        return parse_instance_or_example(tensor, input_pb_type)
      elif input_pb_type != PbType.EXAMPLEBATCH:
        return parse_instance_or_example(tensor, output_pb_type)
      else:
        return parse_example_batch(tensor, output_pb_type)

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=lagrangex_header,
                            has_sort_id=has_sort_id,
                            kafka_dump=kafka_dump,
                            kafka_dump_prefix=kafka_dump_prefix,
                            input_pb_type=input_pb_type,
                            output_pb_type=output_pb_type)
        if add_action_fn is not None:
          dataset = dataset.map(add_action_fn)

        if input_pb_type == PbType.EXAMPLEBATCH:
          variant_type = 'instance' if output_pb_type == PbType.INSTANCE else 'example'
          dataset = dataset.instance_reweight(
              action_priority="2,7,0,1,3,4,5,6,8,9,10,11",
              reweight=
              "0:0:1,1:0:1,2:3:-1,3:0:1,4:0:1,5:0:1,6:0:1,7:6:1,8:0:1,9:0:1,10:0:1,11:0:-1",
              variant_type=variant_type)
        if filter_fn is not None:
          dataset = dataset.filter(filter_fn)

        batch_size = 4
        dataset = dataset.batch(batch_size, drop_remainder=True).map(parser)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)
        element = it.get_next()

        results = list()
        for _ in range(num_return_items):
          try:
            element_result = sess.run(element)
            results.append(element_result[return_result_key])
          except tf.errors.OutOfRangeError:
            break
        return results

  def test_input_instance_output_instance(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.INSTANCE,
                                     output_pb_type=PbType.INSTANCE)
    self.assertAllEqual(actions[0], [[1, 0], [1, 0], [1, 0], [1, 0]])
    self.assertAllEqual(actions[1], [[1, 0], [1, 0], [1, 0], [1, 0]])

  def test_input_instance_output_instance_add_action(self):
    actions = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: add_action(
            variant, 'sample_rate', 'ge', 0, 2, variant_type='instance'))
    self.assertAllEqual(actions[0], [[1, 2], [1, 2], [1, 2], [1, 2]])
    self.assertAllEqual(actions[1], [[1, 2], [1, 2], [1, 2], [1, 2]])

  def test_input_instance_output_example(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.INSTANCE,
                                     output_pb_type=PbType.EXAMPLE)
    self.assertAllEqual(actions[0],
                        [[1, 0, 0], [1, 0, 0], [1, 0, 0], [1, 0, 0]])
    self.assertAllEqual(actions[1],
                        [[1, 0, 0], [1, 0, 0], [1, 0, 0], [1, 0, 0]])

  def test_input_instance_output_example_add_action(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.INSTANCE,
                                     output_pb_type=PbType.EXAMPLE,
                                     add_action_fn=lambda variant: add_action(
                                         variant,
                                         'req_time',
                                         'between', [1622667900, 1622667911],
                                         2,
                                         variant_type='example'))
    self.assertAllEqual(actions[0],
                        [[1, 2, 0], [1, 2, 0], [1, 2, 0], [1, 2, 0]])
    self.assertAllEqual(actions[1],
                        [[1, 2, 0], [1, 0, 0], [1, 0, 0], [1, 0, 0]])

  def test_input_example_output_instance(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.EXAMPLE,
                                     output_pb_type=PbType.INSTANCE)
    self.assertAllEqual(actions[0], [[1, 0], [1, 0], [1, 0], [1, 0]])
    self.assertAllEqual(actions[1], [[1, 0], [1, 0], [1, 0], [1, 0]])

  def test_input_example_output_instance_add_action(self):
    actions = self.pb_dataset_target(
        input_pb_type=PbType.EXAMPLE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: add_action(variant,
                                                 'req_time',
                                                 'in', [1622667900, 1622667911],
                                                 2,
                                                 variant_type='instance'))
    self.assertAllEqual(actions[0], [[1, 2], [1, 2], [1, 0], [1, 2]])
    self.assertAllEqual(actions[1], [[1, 2], [1, 2], [1, 2], [1, 0]])

  def test_input_example_output_example(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.EXAMPLE,
                                     output_pb_type=PbType.EXAMPLE)
    self.assertAllEqual(actions[0],
                        [[1, 0, 0], [1, 0, 0], [1, 0, 0], [1, 0, 0]])
    self.assertAllEqual(actions[1],
                        [[1, 0, 0], [1, 0, 0], [1, 0, 0], [1, 0, 0]])

  def test_input_example_output_example_add_action(self):
    actions = self.pb_dataset_target(
        input_pb_type=PbType.EXAMPLE,
        output_pb_type=PbType.EXAMPLE,
        add_action_fn=lambda variant: add_action(
            variant, 'uid', 'eq', 62975225690081677, 2, variant_type='example'))
    self.assertAllEqual(actions[0],
                        [[1, 0, 0], [1, 0, 0], [1, 2, 0], [1, 0, 0]])
    self.assertAllEqual(actions[1],
                        [[1, 0, 0], [1, 0, 0], [1, 2, 0], [1, 0, 0]])

  def test_input_example_batch_output_instance(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.EXAMPLEBATCH,
                                     output_pb_type=PbType.INSTANCE)
    self.assertAllEqual(actions[0],
                        [[2, 0, 0], [2, 0, 0], [2, 0, 0], [2, 0, 0]])
    self.assertAllEqual(actions[1],
                        [[2, 0, 0], [2, 0, 0], [2, 0, 0], [2, 0, 0]])

  def test_input_example_batch_output_instance_add_action(self):
    actions = self.pb_dataset_target(
        input_pb_type=PbType.EXAMPLEBATCH,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: add_action(variant,
                                                 'video_finish_percent',
                                                 'ge',
                                                 0,
                                                 3,
                                                 variant_type='instance'))
    self.assertAllEqual(actions[0],
                        [[2, 3, 0], [2, 3, 0], [2, 3, 0], [2, 3, 0]])
    self.assertAllEqual(actions[1],
                        [[2, 3, 0], [2, 3, 0], [2, 3, 0], [2, 3, 0]])

  def test_input_example_batch_output_example(self):
    actions = self.pb_dataset_target(input_pb_type=PbType.EXAMPLEBATCH,
                                     output_pb_type=PbType.EXAMPLE)
    self.assertAllEqual(actions[0],
                        [[2, 0, 0], [2, 0, 0], [2, 0, 0], [2, 0, 0]])
    self.assertAllEqual(actions[1],
                        [[2, 0, 0], [2, 0, 0], [2, 0, 0], [2, 0, 0]])

  def test_input_example_batch_output_example_add_action(self):
    actions = self.pb_dataset_target(
        input_pb_type=PbType.EXAMPLEBATCH,
        output_pb_type=PbType.EXAMPLE,
        add_action_fn=lambda variant: add_action(
            variant, 'video_finish_percent', 'le', 0, 3, variant_type='example')
    )
    self.assertAllEqual(actions[0],
                        [[2, 3, 0], [2, 3, 0], [2, 3, 0], [2, 3, 0]])
    self.assertAllEqual(actions[1],
                        [[2, 3, 0], [2, 3, 0], [2, 3, 0], [2, 3, 0]])

  def test_input_instance_output_instance_add_label(self):
    mock_batch_num = 100
    add_label_config = '1,2:3:1.0;4::0.5'

    def mock_instance_for_add_label(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[], [], [], []]

      # for task1: 1,2 -> positive, 3     -> negative
      # for task2: 4   -> positive, other -> negative/invalid(depends on sampling)

      # instance1: task1 -> positive, task2 -> positive
      # instance2: task1 -> positive, task2 -> negative/invalid(depends on sampling)
      # instance3: task1 -> negative, task2 -> positive
      # instance4: task1 -> invalid,  task2 -> negative/invalid(depends on sampling)
      actions = [[1, 2, 4], [1], [3, 4], [5]]
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action in zip(labels, actions):
            instance = generate_instance(label, action)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_add_label(mock_batch_num)
    logging.info('file_name: %s', file_name)

    def parser(tensor: tf.Tensor):
      return parse_instances(tensor,
                             fidv1_features=list(features.values()),
                             dense_features=['label'],
                             dense_feature_shapes=[2],
                             dense_feature_types=[tf.float32],
                             extra_features=[
                                 'uid', 'req_time', 'item_id', 'actions',
                                 'video_finish_percent'
                             ],
                             extra_feature_shapes=[1, 1, 1, 3, 1])

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=False,
                            has_sort_id=True,
                            kafka_dump=False,
                            kafka_dump_prefix=False,
                            input_pb_type=PbType.INSTANCE,
                            output_pb_type=PbType.INSTANCE)
        dataset = dataset.map(
            lambda variant: add_label(variant,
                                      config=add_label_config,
                                      negative_value=-1.0,
                                      new_sample_rate=1.0,
                                      variant_type='instance'))
        dataset = dataset.filter(lambda variant: filter_by_label(
            variant, label_threshold=[-100, -100], variant_type='instance'))

        batch_size = 4
        dataset = dataset.batch(batch_size, drop_remainder=False).map(parser)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)

        valid_instance_num = 0
        for _ in range(mock_batch_num):
          try:
            element = it.get_next()
            element_result = sess.run(element)
            valid_instance_num += len(element_result['label'])
          except tf.errors.OutOfRangeError:
            break
    logging.info('Valid instance number: %d', valid_instance_num)
    self.assertAllInRange(valid_instance_num, 340, 360)
    os.remove(file_name)

  def test_input_instance_output_instance_label_upper_bound(self):
    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: label_upper_bound(
            variant, label_upper_bounds=[0.5, 0.5], variant_type='instance'),
        return_result_key='label')
    self.assertAllEqual(labels[0], [[0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5]])
    self.assertAllEqual(labels[1], [[0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5]])

  def test_input_instance_output_instance_label_normalization(self):
    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: label_normalization(
            variant,
            norm_methods=['scale', 'repow'],
            norm_values=[0.5, 3],
            variant_type='instance'),
        return_result_key='label')
    self.assertAllEqual(labels[0], [[0, 8], [0, 8], [0, 8], [0, 8]])
    self.assertAllEqual(labels[1], [[0, 8], [0, 8], [0, 8], [0, 8]])

  def test_input_examplebatch_output_instance_use_field_as_label(self):
    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: use_field_as_label(
            variant, 'sample_rate', False, 0, variant_type='instance'),
        return_result_key='label')
    self.assertAllEqual(labels[0], [[1, 1], [1, 1], [1, 1], [1, 1]])
    self.assertAllEqual(labels[1], [[1, 1], [1, 1], [1, 1], [1, 1]])

    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: use_field_as_label(label_upper_bound(
            variant, label_upper_bounds=[0.5, 0.5], variant_type='instance'),
                                                         'sample_rate',
                                                         True,
                                                         1.1,
                                                         variant_type='instance'
                                                        ),
        return_result_key='label')
    # Original label is [0, 0.5], new label = max(original_label, [1, 1])
    self.assertAllEqual(labels[0], [[1, 1], [1, 1], [1, 1], [1, 1]])
    self.assertAllEqual(labels[1], [[1, 1], [1, 1], [1, 1], [1, 1]])

    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        add_action_fn=lambda variant: use_field_as_label(label_upper_bound(
            variant, label_upper_bounds=[0.5, 0.5], variant_type='instance'),
                                                         'sample_rate',
                                                         True,
                                                         0.9,
                                                         variant_type='instance'
                                                        ),
        return_result_key='label')
    # Original label is [0, 0.5], new label = max(original_label, [0, 0])
    self.assertAllEqual(labels[0], [[0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5]])
    self.assertAllEqual(labels[1], [[0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5]])

  def test_input_instance_output_instance_filter_by_label_equals(self):
    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        filter_fn=lambda variant: filter_by_label(variant,
                                                  label_threshold=[0, 1],
                                                  filter_equal=False,
                                                  variant_type='instance'),
        return_result_key='label',
        num_return_items=100)
    self.assertEqual(len(labels), 100)
    self.assertAllEqual(labels[0], [[0, 1], [0, 1], [0, 1], [0, 1]])
    self.assertAllEqual(labels[1], [[0, 1], [0, 1], [0, 1], [0, 1]])

    labels = self.pb_dataset_target(
        input_pb_type=PbType.INSTANCE,
        output_pb_type=PbType.INSTANCE,
        filter_fn=lambda variant: filter_by_label(variant,
                                                  label_threshold=[0, 1],
                                                  filter_equal=True,
                                                  variant_type='instance'),
        return_result_key='label',
        num_return_items=100)
    self.assertEqual(len(labels), 49)
    self.assertAllEqual(labels[0], [[0, 2], [0, 2], [0, 2], [0, 2]])
    self.assertAllEqual(labels[1], [[0, 2], [0, 2], [0, 2], [0, 2]])

  def test_input_instance_output_instance_scatter_label(self):
    mock_batch_num = 1
    scatter_label_config = '100:3,200:1,300:4'

    def mock_instance_for_scatter_label(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], []]
      actions = [[], [], [], []]
      chnids = [0, 100, 200, 300]
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, chnid in zip(labels, actions, chnids):
            instance = generate_instance(label, action, chnid)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_scatter_label(mock_batch_num)
    logging.info('file_name: %s', file_name)

    def parser(tensor: tf.Tensor):
      return parse_instances(tensor,
                             fidv1_features=list(features.values()),
                             dense_features=['label'],
                             dense_feature_shapes=[5],
                             dense_feature_types=[tf.float32],
                             extra_features=[
                                 'uid', 'req_time', 'item_id', 'actions',
                                 'video_finish_percent'
                             ],
                             extra_feature_shapes=[1, 1, 1, 3, 1])

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=False,
                            has_sort_id=True,
                            kafka_dump=False,
                            kafka_dump_prefix=False,
                            input_pb_type=PbType.INSTANCE,
                            output_pb_type=PbType.INSTANCE)
        dataset = dataset.map(lambda variant: scatter_label(
            variant, config=scatter_label_config, variant_type='instance'))
        dataset = dataset.filter(lambda variant: filter_by_label(
            variant,
            label_threshold=[-100, -100, -100, -100, -100],
            variant_type='instance'))

        batch_size = 4
        dataset = dataset.batch(batch_size, drop_remainder=False).map(parser)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)

        try:
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['label']), 2)
          self.assertAllClose(
              element_result['label'],
              [[
                  -3.4028235e+38, -3.4028235e+38, -3.4028235e+38, 2.0000000e+00,
                  -3.4028235e+38
              ],
               [
                   -3.4028235e+38, 3.0000000e+00, -3.4028235e+38,
                   -3.4028235e+38, -3.4028235e+38
               ]])
        except tf.errors.OutOfRangeError:
          self.assertTrue(False)
    os.remove(file_name)

  def test_filter_by_bytes_value(self):
    mock_batch_num = 200
    
    def mock_instance_for_filter_by_bytes_value(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], []]
      actions = [[], [], [], []]
      req_ids = ['abckjhfjh', 'kjhfjh', 'huggfyfixyz', '']
      chnids = [10, 20, 30, 40]
      dids = ['hello', 'world', '300', '400']
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, chnid, did, req_id in zip(labels, actions, chnids, dids, req_ids):
            instance = generate_instance(label, action, chnid=chnid, did=did, req_id=req_id,
                                         write_line_id_to_feature=True, shuffle_features=True)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_filter_by_bytes_value(mock_batch_num)
    logging.info('file_name: %s', file_name)
    
    def parser(tensor: tf.Tensor):
      return parse_examples(tensor,
                            sparse_features=list(features.keys()),
                            dense_features=['label', 'req_id'],
                            dense_feature_shapes=[5, 1],
                            dense_feature_types=[tf.float32, tf.string],
                            extra_features=['uid', 'req_time', 'did'],
                            extra_feature_shapes=[1, 1, 1])

    config = tf.compat.v1.ConfigProto()
    config.graph_options.rewrite_options.disable_meta_optimizer = True

    def filter_fn(ts):
      return filter_by_value(ts,
                             field_name='req_id',
                             op='endswith',
                             variant_type='example',
                             operand=['kjhfjh', 'huggfyfi'])

    def feature_filter_fn(ts):
      return filter_by_feature_value(ts,
                             field_name='req_id',
                             op='endswith',
                             operand=['kjhfjh', 'huggfyfi'],
                             field_type='bytes')

    with self.session(config=config) as sess:
      dataset = PBDataset(file_name=file_name,
                          lagrangex_header=False,
                          has_sort_id=True,
                          kafka_dump=False,
                          kafka_dump_prefix=False,
                          input_pb_type=PbType.INSTANCE,
                          output_pb_type=PbType.EXAMPLE)
      dataset_filter = dataset.filter(filter_fn)
      dataset_feature_filter = dataset.filter(feature_filter_fn)
      batch_size = 4
      dataset_filter = dataset_filter.batch(batch_size, drop_remainder=False).map(parser)
      dataset_feature_filter = dataset_feature_filter.batch(batch_size, drop_remainder=False).map(parser)

      num_parallel_calls = 4
      dataset_feature_filter_parallel = dataset.map(map_func=lambda x: x, num_parallel_calls=num_parallel_calls) \
                                               .filter(feature_filter_fn) \
                                               .batch(100, drop_remainder=False).map(parser)

      try:
        it = tf.compat.v1.data.make_one_shot_iterator(dataset_filter)
        element = it.get_next()
        result = sess.run(element)
        self.assertAllEqual(len(result['req_id']), 4)
        self.assertAllEqual(result['req_id'], [[b'abckjhfjh'], [b'kjhfjh'], [b'abckjhfjh'], [b'kjhfjh']])

        it = tf.compat.v1.data.make_one_shot_iterator(dataset_feature_filter)
        element = it.get_next()
        result = sess.run(element)
        self.assertAllEqual(len(result['req_id']), 4)
        self.assertAllEqual(result['req_id'], [[b'abckjhfjh'], [b'kjhfjh'], [b'abckjhfjh'], [b'kjhfjh']])
        
        # test for parallelism ("cached_feature_index" in kernel impl)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset_feature_filter_parallel)
        element = it.get_next()
        result = sess.run(element)
        self.assertAllEqual(len(result['req_id']), 100)
        self.assertAllEqual(result['req_id'], [[b'abckjhfjh'], [b'kjhfjh']] * 50)

      except tf.errors.OutOfRangeError:
        self.assertTrue(False)

    os.remove(file_name)
    
  def test_filter_by_float_value(self):
    mock_batch_num = 200
    
    def mock_instance_for_filter_by_float_value(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], []]
      actions = [[], [], [], []]
      req_ids = ['abckjhfjh', 'kjhfjh', 'huggfyfixyz', 'mbzc']
      video_play_times = [1.0, 2.0, 3.0, 4.0]
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, req_id, video_play_time in zip(labels, actions, req_ids, video_play_times):
            instance = generate_instance(label, action, req_id=req_id, video_play_time=video_play_time,
                                         write_line_id_to_feature=True, shuffle_features=True)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_filter_by_float_value(mock_batch_num)
    logging.info('file_name: %s', file_name)
    
    def parser(tensor: tf.Tensor):
      return parse_examples(tensor,
                            sparse_features=list(features.keys()),
                            dense_features=['label', 'req_id'],
                            dense_feature_shapes=[5, 1],
                            dense_feature_types=[tf.float32, tf.string],
                            extra_features=['uid', 'req_time', 'did'],
                            extra_feature_shapes=[1, 1, 1])

    config = tf.compat.v1.ConfigProto()
    config.graph_options.rewrite_options.disable_meta_optimizer = True

    def feature_filter_fn(ts):
      return filter_by_feature_value(ts,
                             field_name='video_play_time',
                             op='gt',
                             operand=2.5,
                             field_type='float')

    with self.session(config=config) as sess:
      dataset = PBDataset(file_name=file_name,
                          lagrangex_header=False,
                          has_sort_id=True,
                          kafka_dump=False,
                          kafka_dump_prefix=False,
                          input_pb_type=PbType.INSTANCE,
                          output_pb_type=PbType.EXAMPLE)
      dataset_feature_filter = dataset.filter(feature_filter_fn)
      batch_size = 4
      dataset_feature_filter = dataset_feature_filter.batch(batch_size, drop_remainder=False).map(parser)


      try:
        it = tf.compat.v1.data.make_one_shot_iterator(dataset_feature_filter)
        element = it.get_next()
        result = sess.run(element)
        self.assertAllEqual(len(result['req_id']), 4)
        self.assertAllEqual(result['req_id'], [[b'huggfyfixyz'], [b'mbzc'], [b'huggfyfixyz'], [b'mbzc']])

      except tf.errors.OutOfRangeError:
        self.assertTrue(False)

    os.remove(file_name)


  def test_filter_by_value_not_in(self):
    mock_batch_num = 1

    def mock_instance_for_filter_by_value(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], [], []]
      actions = [[], [], [], [], []]
      chnids = [10, 20, 30, 40, 666]
      dids = ['hello', 'world', 'excluded', '300', '400']
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, chnid, did in zip(labels, actions, chnids, dids):
            instance = generate_instance(label, action, chnid, did, write_line_id_to_feature=True)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_filter_by_value(mock_batch_num)
    logging.info('file_name: %s', file_name)

    # generate FilterValues serialized files
    tmp_filter_values_file_string = tempfile.mkstemp()[1]
    with tf.io.gfile.GFile(tmp_filter_values_file_string, 'w') as f:
      filter_values = example_pb2.FilterValues()
      filter_values.bytes_list.value.extend([b'hello', b'world', b'excluded'])
      f.write(filter_values.SerializeToString())
    tmp_filter_values_file_int64 = tempfile.mkstemp()[1]
    with tf.io.gfile.GFile(tmp_filter_values_file_int64, 'w') as f:
      filter_values = example_pb2.FilterValues()
      filter_values.int64_list.value.extend([20, 30, 666])
      f.write(filter_values.SerializeToString())

    def parser(tensor: tf.Tensor):
      return parse_examples(tensor,
                            sparse_features=list(features.keys()),
                            dense_features=['label'],
                            dense_feature_shapes=[5],
                            dense_feature_types=[tf.float32],
                            extra_features=['uid', 'req_time', 'did'],
                            extra_feature_shapes=[1, 1, 1])

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset_base = PBDataset(file_name=file_name,
                                 lagrangex_header=False,
                                 has_sort_id=True,
                                 kafka_dump=False,
                                 kafka_dump_prefix=False,
                                 input_pb_type=PbType.INSTANCE,
                                 output_pb_type=PbType.EXAMPLE)
        dataset_filter_by_list = dataset_base.filter(
            lambda variant: filter_by_value(variant,
                                            field_name='did',
                                            op='not-in',
                                            operand=['hello', 'world'],
                                            variant_type='example'))
        dataset_filter_by_file_string = dataset_base.filter(
            lambda variant: filter_by_value(variant,
                                            field_name='did',
                                            op='not-in',
                                            operand=None,
                                            operand_filepath=
                                            tmp_filter_values_file_string,
                                            variant_type='example'))
        dataset_filter_by_file_int64 = dataset_base.filter(
            lambda variant: filter_by_value(variant,
                                            field_name='chnid',
                                            op='in',
                                            operand=None,
                                            operand_filepath=
                                            tmp_filter_values_file_int64,
                                            variant_type='example'))
        dataset_feature_filter_by_list = dataset_base.filter(
            lambda variant: filter_by_feature_value(variant,
                                                    field_name='did',
                                                    op='not-in',
                                                    operand=['hello', 'world'],
                                                    field_type='bytes'))
        dataset_feature_filter_by_file_string = dataset_base.filter(
            lambda variant: filter_by_feature_value(variant,
                                                    field_name='did',
                                                    op='not-in',
                                                    operand=None,
                                                    operand_filepath=
                                                    tmp_filter_values_file_string,
                                                    field_type='bytes'))
        dataset_feature_filter_by_file_int64 = dataset_base.filter(
            lambda variant: filter_by_feature_value(variant,
                                                    field_name='chnid',
                                                    op='in',
                                                    operand=None,
                                                    operand_filepath=
                                                    tmp_filter_values_file_int64,
                                                    field_type='int64'))

        batch_size = 5
        dataset_filter_by_list = dataset_filter_by_list.batch(
            batch_size, drop_remainder=False).map(parser)
        dataset_filter_by_file_string = dataset_filter_by_file_string.batch(
            batch_size, drop_remainder=False).map(parser)
        dataset_filter_by_file_int64 = dataset_filter_by_file_int64.batch(
            batch_size, drop_remainder=False).map(parser)
        dataset_feature_filter_by_list = dataset_feature_filter_by_list.batch(
            batch_size, drop_remainder=False).map(parser)
        dataset_feature_filter_by_file_string = dataset_feature_filter_by_file_string.batch(
            batch_size, drop_remainder=False).map(parser)
        dataset_feature_filter_by_file_int64 = dataset_feature_filter_by_file_int64.batch(
            batch_size, drop_remainder=False).map(parser)

        try:
          # test for filter by not-in list
          it = tf.compat.v1.data.make_one_shot_iterator(dataset_filter_by_list)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 3)
          self.assertAllEqual(element_result['did'], [[b'excluded'], [b'300'], [b'400']])

          it = tf.compat.v1.data.make_one_shot_iterator(dataset_feature_filter_by_list)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 3)
          self.assertAllEqual(element_result['did'], [[b'excluded'], [b'300'], [b'400']])

          # test for filter by not-in file
          it = tf.compat.v1.data.make_one_shot_iterator(
              dataset_filter_by_file_string)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 2)
          self.assertAllEqual(element_result['did'], [[b'300'], [b'400']])
          
          it = tf.compat.v1.data.make_one_shot_iterator(
              dataset_feature_filter_by_file_string)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 2)
          self.assertAllEqual(element_result['did'], [[b'300'], [b'400']])

          # test for filter by in file
          it = tf.compat.v1.data.make_one_shot_iterator(
              dataset_filter_by_file_int64)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 3)
          self.assertAllEqual(element_result['did'], [[b'world'], [b'excluded'], [b'400']])

          it = tf.compat.v1.data.make_one_shot_iterator(
              dataset_feature_filter_by_file_int64)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 3)
          self.assertAllEqual(element_result['did'], [[b'world'], [b'excluded'], [b'400']])

        except tf.errors.OutOfRangeError:
          self.assertTrue(False)

    os.remove(file_name)
    os.remove(tmp_filter_values_file_string)
    os.remove(tmp_filter_values_file_int64)
    
  def test_filter_by_value_all(self):
    mock_batch_num = 1

    def mock_instance_for_filter_by_value(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], [], []]
      actions = [[], [], [], [], []]
      multi_chnids = [[10], [20, 30], [20, 30, 666], [40], [666]]
      dids = ['hello', 'world', 'excluded', '300', '400']
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, chnids, did in zip(labels, actions, multi_chnids, dids):
            instance = generate_instance(label, action, chnid=None, did=did, chnids=chnids, write_line_id_to_feature=True)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_filter_by_value(mock_batch_num)
    logging.info('file_name: %s', file_name)

    def parser(tensor: tf.Tensor):
      return parse_examples(tensor,
                            sparse_features=list(features.keys()),
                            dense_features=['label'],
                            dense_feature_shapes=[5],
                            dense_feature_types=[tf.float32],
                            extra_features=['uid', 'req_time', 'did'],
                            extra_feature_shapes=[1, 1, 1])
      
    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset_base = PBDataset(file_name=file_name,
                                 lagrangex_header=False,
                                 has_sort_id=True,
                                 kafka_dump=False,
                                 kafka_dump_prefix=False,
                                 input_pb_type=PbType.INSTANCE,
                                 output_pb_type=PbType.EXAMPLE)
        dataset_feature_filter_by_file_int64 = dataset_base.filter(
              lambda variant: filter_by_feature_value(variant,
                                                      field_name='chnids',
                                                      op='all',
                                                      operand=[20, 30, 666],
                                                      operand_filepath=None,
                                                      field_type='int64'))
        batch_size = 5
        dataset_feature_filter_by_file_int64 = dataset_feature_filter_by_file_int64.batch(
            batch_size, drop_remainder=False).map(parser)

        try:
          it = tf.compat.v1.data.make_one_shot_iterator(
              dataset_feature_filter_by_file_int64)
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(len(element_result['did']), 1)
          self.assertAllEqual(element_result['did'], [[b'excluded']])

        except tf.errors.OutOfRangeError:
          self.assertTrue(False)
    
    os.remove(file_name)

  def test_map_id(self):
    inputs = tf.constant([123, 456, 789, 912], dtype=tf.int32)
    map_dict = {123: 0, 456: 1, 789: 2}
    config = tf.compat.v1.ConfigProto()
    config.graph_options.rewrite_options.disable_meta_optimizer = True
    with self.session(config=config) as sess:
      out_ts = map_id(tensor=inputs, map_dict=map_dict)
      out = sess.run(out_ts)
      self.assertListEqual(list(out), [0, 1, 2, -1])

  def test_filter_by_fids(self):
    mock_batch_num = 1
    batch_size = 4

    def mock_instance(batch_num: int = 200):
      tmpfile = tempfile.mkstemp()[1]
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for i in range(batch_size + 1):
            instance = generate_instance(
                [], [],
                fid_v1_list=[get_fid_v1(2, i),
                             get_fid_v1(3, i)] if i > 0 else [get_fid_v1(2, i)])
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance(mock_batch_num)
    logging.info('file_name: %s', file_name)

    def parser(tensor: tf.Tensor):
      return parse_instances(tensor, fidv1_features=[2, 3])

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=False,
                            has_sort_id=True,
                            kafka_dump=False,
                            kafka_dump_prefix=False,
                            input_pb_type=PbType.INSTANCE,
                            output_pb_type=PbType.INSTANCE)
        dataset = dataset.filter(lambda variant: filter_by_fids(
            variant, select_slots=[2, 3], variant_type='instance'))

        dataset = dataset.batch(batch_size, drop_remainder=False).map(parser)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)

        try:
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllEqual(element_result['slot_2'].values,
                              [get_fid_v1(2, i + 1) for i in range(batch_size)])
          self.assertAllEqual(element_result['slot_3'].values,
                              [get_fid_v1(3, i + 1) for i in range(batch_size)])
        except tf.errors.OutOfRangeError:
          self.assertTrue(False)
    os.remove(file_name)

  def test_multi_label_gen(self):
    mock_batch_num = 1
    head_to_idx = {'ios': 3, 'wp': 1, 'android': 4, 'other': 0}

    def mock_instance_for_multi_label_gen(batch_num: int = 10):
      tmpfile = tempfile.mkstemp()[1]
      labels = [[1], [2], [3], [1]]
      actions = [[1, 2], [3], [2], [1]]
      chnids = [0, 100, 200, 300]
      device_types = ['ios', 'wp', 'android', 'ios']
      with io.open(tmpfile, 'wb') as writer:
        for _ in range(batch_num):
          for label, action, chnid, device_type in zip(labels, actions, chnids,
                                                       device_types):
            instance = generate_instance(label,
                                         action,
                                         chnid,
                                         device_type=device_type)
            write_instance_into_file(writer, instance)
      return tmpfile

    file_name = mock_instance_for_multi_label_gen(mock_batch_num)
    logging.info('file_name: %s', file_name)

    def parser(tensor: tf.Tensor):
      return parse_instances(tensor,
                             dense_features=['label'],
                             dense_feature_shapes=[5],
                             dense_feature_types=[tf.float32],
                             extra_features=[
                                 'uid', 'req_time', 'item_id', 'actions',
                                 'device_type'
                             ],
                             extra_feature_shapes=[1, 1, 1, 3, 1])

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=False,
                            has_sort_id=True,
                            kafka_dump=False,
                            kafka_dump_prefix=False,
                            input_pb_type=PbType.INSTANCE,
                            output_pb_type=PbType.INSTANCE)
        dataset = dataset.map(
            lambda variant: multi_label_gen(variant,
                                            head_to_index=head_to_idx,
                                            head_field='device_type',
                                            use_origin_label=False,
                                            pos_actions=[3, 2],
                                            neg_actions=[1],
                                            action_priority='4,3,2,1,0',
                                            variant_type='instance'))

        batch_size = 4
        dataset = dataset.batch(batch_size, drop_remainder=False).map(parser)
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)
        try:
          element = it.get_next()
          element_result = sess.run(element)
          self.assertAllClose(
              element_result['label'],
              [[
                  -3.4028235e+38, -3.4028235e+38, -3.4028235e+38, 1.0000000e+00,
                  -3.4028235e+38
              ],
               [
                   -3.4028235e+38, 1.0000000e+00, -3.4028235e+38,
                   -3.4028235e+38, -3.4028235e+38
               ],
               [
                   -3.4028235e+38, -3.4028235e+38, -3.4028235e+38,
                   -3.4028235e+38, 1.0000000e+00
               ],
               [
                   -3.4028235e+38, -3.4028235e+38, -3.4028235e+38,
                   0.0000000e+00, -3.4028235e+38
               ]])
        except tf.errors.OutOfRangeError:
          self.assertTrue(False)
    os.remove(file_name)

  def test_string_to_variant(self):
    insts = []
    has_header, lg_header_flag = True, False
    sort_id, kafka_dump, kafka_dump_prefix = True, False, True
    for i in range(10):
      inst = proto_parser_pb2.Instance()
      inst.fid.extend([i for i in range(1, 20)])
      inst.line_id.chnid = 1
      inst_str = inst.SerializeToString()
      if lg_header_flag:
        header = lg_header(None)
      else:
        header = sort_header(sort_id, kafka_dump, kafka_dump_prefix)
      if i == 3:
        inst_str = b''
      if has_header:
        data = struct.pack(f'<{len(header)}sQ{len(inst_str)}s', header,
                           len(inst_str), inst_str)
      else:
        data = inst_str
      insts.append(data)
    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      ips = tf.constant(value=insts, dtype=tf.string, shape=(10,), name='insts')
      ops = string_to_variant(ips,
                              variant_type='instance',
                              has_header=has_header,
                              lagrangex_header=lg_header_flag,
                              has_sort_id=sort_id,
                              kafka_dump=kafka_dump,
                              kafka_dump_prefix=kafka_dump_prefix,
                              chnids=[1, 2],
                              datasources=["1", "2"],
                              default_datasource='3')
      zeros = variant_to_zeros(ops)
      with self.session(config=config) as sess:
        element_result = sess.run(zeros)
    self.assertAllEqual(ips.shape, ops.shape)

  def test_has_variant(self):
    inst = proto_parser_pb2.Instance()
    inst.fid.extend([i for i in range(1, 20)])
    inst_str = inst.SerializeToString()
    data = struct.pack(f'<Q{len(inst_str)}s', len(inst_str), inst_str)

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      ips = tf.constant(value=[data], dtype=tf.string, shape=tuple())
      ops = string_to_variant(ips,
                              variant_type='instance',
                              has_header=True,
                              lagrangex_header=False,
                              has_sort_id=False,
                              kafka_dump=False,
                              kafka_dump_prefix=False)
      out = has_variant(ops, variant_type='instance')
      with self.session(config=config) as sess:
        element_result = sess.run(out)
        self.assertTrue(element_result)

  def test_switch_slot_batch(self):
    input_pb_type = PbType.EXAMPLE
    output_pb_type = PbType.EXAMPLE
    if input_pb_type == PbType.EXAMPLE:
      lagrangex_header = False
      has_sort_id, kafka_dump, kafka_dump_prefix = True, True, False
      file_name = "monolith/native_training/data/training_instance/example.pb"
      variant_type = 'example'
    else:
      lagrangex_header = True
      has_sort_id, kafka_dump, kafka_dump_prefix = False, False, False
      file_name = "monolith/native_training/data/training_instance/examplebatch.data"
      variant_type = 'example_batch'

    ss_meta, shared_slot = {}, 10
    selected_slots = [50, 54, 56, 60, 66, 120, 150, 180, 182]
    for slot in selected_slots:
      if slot in {60, 66, 120, 150}:
        ss_meta[f'fc_slot_{slot}'] = (False, shared_slot)
      else:
        ss_meta[f'fc_slot_{slot}'] = (True, shared_slot)

    def parser(tensor: tf.Tensor):
      extra_sf = []
      for name, (inplace, _) in ss_meta.items():
        if not inplace:
          extra_sf.append(f'{name}_share')
      if output_pb_type == PbType.PLAINTEXT:
        return parse_instance_or_example(tensor, input_pb_type, extra_sf)
      elif input_pb_type != PbType.EXAMPLEBATCH:
        return parse_instance_or_example(tensor, output_pb_type, extra_sf)
      else:
        return parse_example_batch(tensor, output_pb_type, extra_sf)

    with tf.Graph().as_default():
      config = tf.compat.v1.ConfigProto()
      config.graph_options.rewrite_options.disable_meta_optimizer = True
      with self.session(config=config) as sess:
        dataset = PBDataset(file_name=file_name,
                            lagrangex_header=lagrangex_header,
                            has_sort_id=has_sort_id,
                            kafka_dump=kafka_dump,
                            kafka_dump_prefix=kafka_dump_prefix,
                            input_pb_type=input_pb_type,
                            output_pb_type=output_pb_type)
        if output_pb_type == PbType.EXAMPLE:
          batch_size = 4
          dataset = dataset.batch(batch_size, drop_remainder=True)
        dataset = dataset.map(lambda batch: switch_slot_batch(batch, ss_meta, variant_type))
        dataset = dataset.map(parser)  # convert fid v1 -> v2
        it = tf.compat.v1.data.make_one_shot_iterator(dataset)
        element = it.get_next()

        for _ in range(10):
          try:
            element_result = sess.run(element)
            for name, (inplace, slot) in ss_meta.items():
              if not inplace:
                ragged_tensor = element_result[f'{name}_share']
                for value in ragged_tensor.values:
                  self.assertEqual(value >> 48, shared_slot)
                ragged_tensor = element_result[name]
                for value in ragged_tensor.values:
                  self.assertNotEqual(value >> 48, shared_slot)
              else:
                ragged_tensor = element_result[name]
                for value in ragged_tensor.values:
                  self.assertEqual(value >> 48, shared_slot)
          except tf.errors.OutOfRangeError:
            break

  def test_gen_fid_mask_int64(self):
    config = tf.compat.v1.ConfigProto()
    config.graph_options.rewrite_options.disable_meta_optimizer = True
    with self.session(config=config) as sess:
      ragged: tf.RaggedTensor = tf.ragged.constant([[1, 2, 3], [3], [], [4, 5, 6]], dtype=tf.int64)
      mask_ts = gen_fid_mask(ragged, 3)
      mask = sess.run(mask_ts)
      exp_res = [1., 1., 0., 0.]
      self.assertListEqual(list(mask), exp_res)

  def test_gen_fid_mask_int32(self):
    config = tf.compat.v1.ConfigProto()
    config.graph_options.rewrite_options.disable_meta_optimizer = True
    with self.session(config=config) as sess:
      ragged: tf.RaggedTensor = tf.ragged.constant([[1, 2, 3], [3], [], [4, 5, 6]],
        dtype=tf.int64, row_splits_dtype=tf.int32)
      mask_ts = gen_fid_mask(ragged, 3)
      mask = sess.run(mask_ts)
      exp_res = [1., 1., 0., 0.]
      self.assertListEqual(list(mask), exp_res)


  def test_negative_sample_with_positive_actions(self):
    neg_counter = 0
    filt_counter = 0
    neg_counter_mismatch = 0
    filt_counter_mismatch = 0
    for i in range(1000):
      inst = proto_parser_pb2.Instance()
      if i % 11 == 0:
        inst.label.append(1)
      else:
        inst.label.append(0)
      if i % 5 == 0:
        # match action=2, drop_rate=0
        inst.line_id.actions.extend([1, 2, 4, 5])
      elif i % 5 == 1:
        # match action=3, drop_rate=1
        inst.line_id.actions.extend([1, 3, 5])
      elif i % 5 == 2:
        # match action=5, drop_rate=0.22
        inst.line_id.actions.extend([5, 6])
      elif i % 5 == 3:
        # match priority, but not in per_action_drop_rate
        inst.line_id.actions.extend([6])
      elif i % 5 == 4:
        # mismatch
        inst.line_id.actions.extend([10, 11, 12])
      inst_str = inst.SerializeToString()
      data = struct.pack(f"<Q{len(inst_str)}s", len(inst_str), inst_str)

      with tf.Graph().as_default():
        config = tf.compat.v1.ConfigProto()
        config.graph_options.rewrite_options.disable_meta_optimizer = True
        ipts = tf.constant(value=[data], dtype=tf.string, shape=tuple())
        variant_op = string_to_variant(ipts,
                                      variant_type="instance",
                                      has_header=True,
                                      lagrangex_header=False,
                                      has_sort_id=False,
                                      kafka_dump=False,
                                      kafka_dump_prefix=False)
        filter_op = negative_sample(variant_op,
                                    drop_rate=0.88,
                                    label_index=0,
                                    threshold=0.5,
                                    variant_type="instance",
                                    action_priority="2,3,4,1,5,6",
                                    per_action_drop_rate="1:1.0,2:0.0,3:1.0,4:0.5,5:0.22")
        with self.session(config=config) as sess:
          filter_result = sess.run(filter_op)
          if i % 11 == 0:
            self.assertTrue(filter_result)
          elif i % 5 == 0:
            self.assertTrue(filter_result)
          elif i % 5 == 1:
            self.assertFalse(filter_result)
          elif i % 5 == 2:
            neg_counter += 1
            if not filter_result:
              filt_counter += 1
          else:
            neg_counter_mismatch += 1
            if not filter_result:
              filt_counter_mismatch += 1
    logging.info("drop_rate_match: {:2f}, drop_rate_mismatch: {:.2f}".format(filt_counter/neg_counter, filt_counter_mismatch/neg_counter_mismatch))


if __name__ == '__main__':
  tf.compat.v1.disable_eager_execution()
  tf.test.main()
