#!/bin/bash
export KAFKA_PATH=$HOME/kafka_2.13-2.8.1
